import { configureStore } from "@reduxjs/toolkit";
import { setupListeners } from '@reduxjs/toolkit/query';
import { UsersApi } from "./src/features/api/userAPISlice";
import { VendorProductsApi } from "./src/features/api/VendorProductsAPISlice";
import AuthSlice from "./src/features/auth/AuthSlice";
import AddProductSlice from "./src/features/product/AddProductSlice";
import VendorDistributorSlice from "./src/features/vendorDistributor/VendorDistributorSlice";

export const Store=configureStore({
    reducer:{
        user:AuthSlice,
        add_product:AddProductSlice,
        vendor_distributor:VendorDistributorSlice,
        [UsersApi.reducerPath]: UsersApi.reducer,
        [VendorProductsApi.reducerPath]: VendorProductsApi.reducer
    },
    middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(UsersApi.middleware,VendorProductsApi.middleware),
});

setupListeners(Store.dispatch);