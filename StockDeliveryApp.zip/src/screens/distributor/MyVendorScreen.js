import React,{useState,useEffect} from 'react';
import {Text, View, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator} from 'react-native';
//import {myVendorsList} from '../../global/Distributor/MyVendors';
import UserInfoCard from '../../components/UserInfoCard';
import Header from '../../components/Header';
import {useSelector, useDispatch} from 'react-redux';
import { getVendors } from '../../features/vendorDistributor/VendorDistributorSlice';
import { colors } from '../../global/Styles';

export default function MyVendorScreen({navigation}) {

  const dispatch = useDispatch();
  const {userInfo} = useSelector(state => state.user);
  const {isLoading, vendorInfo} = useSelector(state => state.vendor_distributor);
  const [vendorData, setVendorData] = useState();

  useEffect(() => {
    dispatch(getVendors({id:userInfo.id}))
      .unwrap()
      .then(originalPromiseResult => {
        console.log('Success ___ My Vendors..');
        console.log(originalPromiseResult);
        setVendorData(vendorInfo);
      })
      .catch(rejectedValueOrSerializedError => {
        console.log(rejectedValueOrSerializedError);
      });
  }, []);


  if (isLoading) {
    return (
      <View style={styles.loader}>
        <ActivityIndicator visible={true} />
      </View>
    );
  } else if (!vendorData) {
    return (
      <View style={styles.loader}>
        <Text style={{color: colors.buttons, fontSize: 20, fontWeight: 'bold'}}>
          Please Wait ....
        </Text>
      </View>
    );
  } else if(vendorData) {
  return (
    <View style={styles.container}>
      <Header navigate={navigation} title="Distributor Dashboard" />
      <View style={styles.textBarTab}>
        <Text style={styles.textTop}>My Vendors List</Text>
      </View>
      <View style={{flex: 1, flexGrow: 1}}>
        <FlatList
          style={{marginTop: 10, marginBottom: 10}}
          horizontal={false}
          showsVerticalScrollIndicator={true}
          data={vendorInfo}
          keyExtractor={(item, index) => index.toString()}
          renderItem={({item}) => (
            <TouchableOpacity onPress={() => alert('My Vendors pressed..')}>
              <UserInfoCard item={item} />
            </TouchableOpacity>
          )}
        />
      </View>
    </View>
  );}
}

const styles = StyleSheet.create({
  loader: {
    flex: 1,
    justifyContent: 'center',
    textAlign: 'center',
    paddingTop: 30,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  container: {
    flex: 1,
    backgroundColor: colors.cardbackground,
  },
  textTop: {
    fontSize: 20,
    fontWeight: 'bold',
    color: colors.buttons,
  },
  textBarTab: {
    alignItems: 'flex-start',
    justifyContent: 'center',
    marginLeft: 5,
    marginTop: 15,
    marginBottom: 10,
    height: 50,
    backgroundColor: colors.grey5,
    padding: 10,
    borderRadius: 10,
  },
  imgStyle: {
    width: 60,
    height: 50,
    borderRadius: 25,
  },
  cardText: {
    color: colors.grey2,
    fontSize: 18,
  },
});
