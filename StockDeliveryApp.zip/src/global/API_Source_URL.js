export const globalAPI='http://192.168.1.107/Stock_Delivery_App_Backend/api'

export const imageURL='http://192.168.1.107/Stock_Delivery_App_Backend/Images/'