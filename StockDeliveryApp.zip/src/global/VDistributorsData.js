export const vendorDistributors=[
    {
    uid:1,
    uname:'Usama Bilal',
    uemail:'BILALOSAMA8@GMAIL.COM',
    umobileno:'03168967345',
    ucity:'Rawalpindi',
    distributionStatus:'approved',
    securityAmountPaid:'200000',
    distributorAddress:'105 Range Road',
    uimage:'https://images.unsplash.com/photo-1621592484082-2d05b1290d7a?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8amV1bmVzfGVufDB8fDB8fA%3D%3D&w=1000&q=80'
},
{
    uid:2,
    uname:'Shoaib Sheikh',
    uemail:'SS678@GMAIL.COM',
    umobileno:'03457967294',
    ucity:'Rawalpindi',
    distributionStatus:'applied',
    securityAmountPaid:'not paid',
    distributorAddress:'24 Harley Street',
    uimage:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQJ_WIjJ9MV_bPsxMTEBSyx3-Zu5pvGsDUowg&usqp=CAUs'
}
]