import React from 'react'
import { createNativeStackNavigator } from '@react-navigation/native-stack'
import MyVendorScreen from '../../screens/distributor/MyVendorScreen'

const myVNavStack=createNativeStackNavigator()

export default function MyVendorsNavStack () {
    return (
      <myVNavStack.Navigator>
            <myVNavStack.Screen
              name='MyVendorScreen' 
              component={MyVendorScreen}
              options={{headerShown:false}}
            />
      </myVNavStack.Navigator>
    )
  }
